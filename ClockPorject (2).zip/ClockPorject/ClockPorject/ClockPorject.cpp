// Author: James Gould
// Date: 11/14/2025
// purpose: Create a display of 12 hour and 24 hour clocks
// It presents the use rwith te option to increase the time
// by one hour, one minute, or one second
//

#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
using namespace std;

void checkTimes(int& hours, int& minutes, int& seconds) {
    while (seconds >= 60) {
        minutes += 1;
        seconds -= 60;
    }

    while (minutes >= 60) {
        hours += 1;
        minutes -= 60;
    }

    while (hours >= 24) {
        hours -= 24;
    }
}

//displays the current hour, minute, and second in the proper format
//if the hour is greater than 12, the 12 hour clock switches from am
//to pm
void displayClock(int hours = 0, int minutes = 0, int seconds = 0) {
    cout << "**************************   **************************" << endl;
    cout << "*     12-hour Clock      *   *     24-hour Clock      *" << endl;

    if (hours <= 12) {
        cout << "*     "; cout << setfill('0') << setw(2) << hours;
        cout << ":"; cout << setfill('0') << setw(2) << minutes;
        cout << ":"; cout << setfill('0') << setw(2) << seconds;
        cout << " A M       *   *     ";

        cout << setfill('0') << setw(2) << hours;
        cout << ":"; cout << setfill('0') << setw(2) << minutes;
        cout << ":"; cout << setfill('0') << setw(2) << seconds;
        cout << "           *" << endl;
    }
    else {
        cout << "*     "; cout << setfill('0') << setw(2) << hours - 12;
        cout << ":"; cout << setfill('0') << setw(2) << minutes;
        cout << ":"; cout << setfill('0') << setw(2) << seconds;
        cout << " P M       *   *     ";

        cout << setfill('0') << setw(2) << hours;
        cout << ":"; cout << setfill('0') << setw(2) << minutes;
        cout << ":"; cout << setfill('0') << setw(2) << seconds;
        cout << "           *" << endl;
    }

    cout << "**************************   **************************" << endl;
}

//The function displays the menu, ask for the users desion, verifies 
// the variable's value, and displays the time in that order
void DisplayMenu(int& hours, int& minutes, int& seconds) {
    bool active = true;
    int  input;

    while (active) {
        cout << "**************************" << endl;
        cout << "* 1 - Add One Hour       *" << endl;
        cout << "* 2 - Add One Minute     *" << endl;
        cout << "* 3 - Add One Second     *" << endl;
        cout << "* 4 - Exit Program       *" << endl;
        cout << "**************************" << endl;

        cin >> input;

        switch (input) {
        case 1: hours += 1;
            break;
        case 2: minutes += 1;
            break;
        case 3: seconds += 1;
            break;
        case 4: active = false;
            break;
        default: cout << "Error: Invalid Input" << endl;
            break;
        }

        if (input >= 1 && input <= 3) {
            checkTimes(hours, minutes, seconds);
            displayClock(hours, minutes, seconds);
        }
    }
}

//The function that starts it all. It ask for intial input for time.
//then displays the menu for the uesr to decide
//*note: The flow chart has the menu come up before the clock.
// I recommend we change it to have the clock show up first*
void StartClock() {
    int hours,
        minutes,
        seconds;

    cout << "Current Hour: ";
    cin >> hours;
    cout << "Current minute: ";
    cin >> minutes;
    cout << "Current second: ";
    cin >> seconds;

    DisplayMenu(hours, minutes, seconds);
    
}

int main()
{
    StartClock();//one line to start it all becuase doing it with no lines would have been annoying
}
